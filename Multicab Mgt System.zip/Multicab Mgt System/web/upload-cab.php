<html>
<head>
	<title>Add Data</title>
</head>

<body>


<?php
include_once("db.php");
 if(isset($_POST['submit'])) {	
     
    
	$source = mysqli_real_escape_string($con, $_POST['source']);
	$destination = mysqli_real_escape_string($con, $_POST['destination']);
	//$number =  mysqli_real_escape_string($con, $_POST['number']);
	$price =  mysqli_real_escape_string($con, $_POST['price']);
	
	$cmp_name  =  mysqli_real_escape_string($con, $_POST['cmp_name']);
	
		
	// checking empty fields
	if( empty($source) || empty($destination) ||empty($price) || empty($cmp_name ))
	{
				
		
		if(empty($source)) {
			echo "<font color='red'>source field is empty.</font><br/>";
		}
		if(empty($destination)) {
			echo "<font color='red'>destination field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>price field is empty.</font><br/>";
		}
		if(empty($cmp_name )) {
			echo "<font color='red'>uber field is empty.</font><br/>";
		}
		
		
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$row = mysqli_query($con, "INSERT INTO cab(source,destination,price,cmp_name) VALUES('$source','$destination','$price','$cmp_name')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='view-cab.php'>View Result</a>";
	}
}
?>
</body>
</html>
