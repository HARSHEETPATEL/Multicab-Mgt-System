<html>

  
<body>


<?php
include_once("db.php");
 if(isset($_POST['submit'])) {	
     
    $name =  mysqli_real_escape_string($con, $_POST['name']);
	$source = mysqli_real_escape_string($con, $_POST['source']);
	$destination = mysqli_real_escape_string($con, $_POST['destination']);
	$number =  mysqli_real_escape_string($con, $_POST['number']);
	$cmp_name =  mysqli_real_escape_string($con, $_POST['cmp_name']);

	
	
	
	
	
		
	// checking empty fields
	if( empty($name) || empty($source) ||empty($destination) || empty($number)||empty($cmp_name))
	{
				
		
		if(empty($name)) {
			echo "<font color='red'>name field is empty.</font><br/>";
		}
		if(empty($source)) {
			echo "<font color='red'>source field is empty.</font><br/>";
		}
		
		if(empty($destination)) {
			echo "<font color='red'>destination field is empty.</font><br/>";
		}
		if(empty($number)) {
			echo "<font color='red'>number field is empty.</font><br/>";
		}
		if(empty($cmp_name)) {
			echo "<font color='red'>company name field is empty.</font><br/>";
		}
		
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$row = mysqli_query($con, "INSERT INTO book_cab(name,source,destination,number,cmp_name) VALUES('$name','$source','$destination','$number','$cmp_name')");
		
		//display success message
		echo "<center><font color='green'><h1>Your Cab successfully Book.</h1></center>";
	 echo "<br/><center><button><a href='pay.php'><font color='#000' font size='5px' >Online Payment</a></button></center>";
	 //echo "<br/><center><button><a href='ticket.php'><font color='#000' font size='5px' > Ticket</a></button></center>";
	 
	}
}
?>
  <!-- Template JavaScript -->
    <script src="assets/js1/jquery-3.3.1.min.js"></script>
    <script src="assets/js1/theme-change.js"></script>
   
    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });
        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!-- //MENU-JS -->
    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- //disable body scroll which navbar is in active -->
    <!-- //bootstrap -->
    <script src="assets/js1/bootstrap.min.js"></script>
</body>

</html>

