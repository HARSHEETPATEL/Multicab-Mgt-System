<?php
//including the database connection file
include("db.php");

//getting id of the data from url
$id = $_GET['id'];

//deleting the row from table
//$row = mysqli_query($mysqli, "DELETE FROM booking WHERE id=$id");

//redirecting to the display page (index.php in our case)
$sql = "DELETE FROM  cab WHERE id=$id";

if ($con->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $con->error;
}

$con->close();
header("Location:view-cab.php");
?>

