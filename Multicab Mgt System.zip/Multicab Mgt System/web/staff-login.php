<?php session_start(); ?>


<?php
include('db.php');
	  
	  $msg="";
       if (isset($_POST['login']))
		{
           $Email =$_POST['Email'];
		   $Password =$_POST['Password'];
		  // $password =sha1($password);
		   $cmp_name =$_POST['cmp_name'];
		   
		   $sql= "SELECT * FROM staff WHERE Email=? And Password=? And cmp_name=?";
		   $stmt=$con->prepare($sql);
		   $stmt->bind_param("sss", $Email ,$Password ,$cmp_name);
		   $stmt->execute();
		   $result = $stmt->get_result();
		   $row = $result->fetch_assoc();
		   
		   session_regenerate_id();
		   $_SESSION['Email']=$row['Email'];
		   $_SESSION['role']=$row['cmp_name'];
		   session_write_close();
		   
		   if($result->num_rows==1 && $_SESSION['role']=="ola"){
			   header("location:view-ola.php");
		   } else if($result->num_rows==1 && $_SESSION['role']=="uber"){
			    header("location:view-uber.php");
		   }else if($result->num_rows==1 && $_SESSION['role']=="red bus"){
			    header("location:view-red-bus.php");
		   }
		   else if($result->num_rows==1 && $_SESSION['role']=="go green"){
			   header("location:view-green.php");
		   }else{
		  
			   $msg = "Username or Password is Incorrect";
		}
	
		}
	?>  
<!DOCTYPE html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content=""/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="assets/css1/style.css" rel='stylesheet' type='text/css' />
<link href="assets/css1/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="assets/css1/font.css" type="text/css"/>
<link href="assets/css1/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="assets/js1/jquery2.0.3.min.js"></script>
</head>
<body>
<div class="log-w3">
<center><h1>Staff Login</h1></center>
<div class="w3layouts-main">
	<h2>Sign In Now</h2>
		<form action="" method="post">
		     
			<input type="email" class="ggg" name="Email" placeholder="E-MAIL" required="">
			<input type="password" class="ggg" name="Password" placeholder="PASSWORD" required="">
			  
			  <?php echo "<font color='white'>Select User Type:</font>";?>   <select name="cmp_name">
			    <option value="ola"> ola</option>
			    <option value="uber"> Uber</option>
			     <option value="red bus"> Red Bus</option>
				<option value="go green"> Go Green</option>
				 </select>
			<input type="submit" value="Sign In" name="login">
			<h5 class="text-danger text-center"><?=$msg;?></h5>
		</form>
</div>
</div>
      
<script src="assets/js1/bootstrap.js"></script>
<script src="assets/js1/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/js1/scripts.js"></script>
<script src="assets/js1/jquery.slimscroll.js"></script>
<script src="assets/js1/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="assets/js1/jquery.scrollTo.js"></script>
</body>
</html>
