<!DOCTYPE html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="assets/css1/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="assets/css1/style.css" rel='stylesheet' type='text/css' />
<link href="assets/css1/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="assets/css1/font.css" type="text/css"/>
<link href="assets/css1/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="assets/css1/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="assets/css1/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="assets/js1/jquery2.0.3.min.js"></script>
<script src="assets/js1/raphael-min.js"></script>
<script src="assets/js1/morris.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    
    
</div>
<!--logo end-->
<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
   
    <!--  notification end -->
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
          <li><a href="index.php"><i class="fa fa-key"></i> Log Out</a></li>
        <!-- user login dropdown start-->
        
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->

<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
					<header class="panel-heading">
                            Staff Information
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form action="upload-staff.php" method="post" class="form"  enctype="multipart/form-data">
								<div class="form-group">
								 <label for="">Company Name:</label>
								 <select name="cmp_name">
								 <option value="ola"> ola</option>
			                     <option value="uber"> Uber</option>
			                     <option value="red bus"> Red Bus</option>
				                 <option value="go green"> Go Green</option>
				                </select>
								</div>
								<div class="form-group">
                                    <label for=""> Staff Name</label>
                                    <input type="text" class="form-control" name="staff_name"   placeholder="Name" required>
                                </div>
								<div class="form-group">
                                    <label for="">Email</label>
                                    <input type="text" class="form-control" name="Email"  placeholder="Range" required>
                                </div>
								<div class="form-group">
                                    <label for="">Password</label>
                                    <input type="text" class="form-control" name="Password"  placeholder="Range" required>
                                </div>
								<div class="form-group">
                                    <label for="">Phone_no</label>
                                    <input type="text" class="form-control" name="phone_no"  placeholder="Range" required>
                                </div>
								
								
                                <button type="submit" name="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
                    </section>
					
					
		</div>
		</div>
		</div>
		
</section>
</section>
								
		</body>
</html>		
								
								
                               
                                
                                
              
