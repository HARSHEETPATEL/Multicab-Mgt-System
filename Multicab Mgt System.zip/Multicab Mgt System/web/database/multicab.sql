-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 02, 2022 at 09:33 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multicab`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Email`, `Password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book_cab`
--

CREATE TABLE `book_cab` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `destination` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `cmp_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_cab`
--

INSERT INTO `book_cab` (`id`, `name`, `source`, `destination`, `number`, `cmp_name`) VALUES
(4, 'ayush', 'nashik', 'pune', '2', 'ola'),
(5, 'puja', 'nashik', 'mumbai', '2', 'uber'),
(6, 'deepa', 'pune', 'mumbai', '3', 'red bus'),
(7, 'seema', 'dhule', 'pune', '1', 'go green'),
(9, 'puja', 'nagpur', 'nagar', '5', 'red bus'),
(10, 'puja', 'nagpur', 'nagar', '5', 'red bus'),
(11, 'puja', 'nagpur', 'nagar', '5', 'red bus'),
(12, 'puja', 'nagpur', 'nagar', '5', 'red bus'),
(13, 'puja', 'nagpur', 'nagar', '5', 'uber'),
(14, 'deepa', 'sinner', 'pune', '2', 'ola'),
(15, 'Manu Malhotra', 'sinner', 'nagar', '1', 'go green'),
(16, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(17, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(18, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(19, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(20, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(21, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(22, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(23, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(24, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(25, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(26, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(27, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(28, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(29, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(30, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(31, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(32, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(33, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(34, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(35, 'deepa', 'sinner', 'nashik', '4', 'uber'),
(36, 'maddy', 'sinner', 'nashik', '2', 'go green'),
(37, 'maddy', 'sinner', 'nashik', '2', 'go green'),
(38, 'maddy', 'sinner', 'nashik', '2', 'go green'),
(39, 'maddy', 'sinner', 'nashik', '2', 'go green'),
(40, 'arayn', 'nagpur', 'pune', '3', 'ola');

-- --------------------------------------------------------

--
-- Table structure for table `cab`
--

CREATE TABLE `cab` (
  `id` int(11) NOT NULL,
  `source` varchar(200) NOT NULL,
  `destination` varchar(200) NOT NULL,
  `price` varchar(150) NOT NULL,
  `cmp_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cab`
--

INSERT INTO `cab` (`id`, `source`, `destination`, `price`, `cmp_name`) VALUES
(14, 'nashik', 'mumbai', '1500', 'ola'),
(15, 'pune', 'sinner', '1000', 'uber'),
(16, 'dhule', 'mumbai', '4000', 'red bus'),
(17, 'pune', 'nashik', '500', 'ola');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(200) NOT NULL,
  `cmp_name` varchar(200) NOT NULL,
  `staff_name` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `phone_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `cmp_name`, `staff_name`, `Email`, `Password`, `phone_no`) VALUES
(4, 'ola', 'puja ', 'kapadne.puja@gmail.com', 'puja', '9765425698'),
(5, 'uber', 'aryan ', 'r@gmail.com', '123', '9876047652'),
(6, 'red bus', 'john', 'john@gmail.com', '123456', '9876454755'),
(7, 'go green', 'seema', 'seema@gmail.com', 'seema', '8795485752');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `cno` int(16) NOT NULL,
  `name` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `Cvv` int(5) NOT NULL,
  `Pin` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `cno`, `name`, `date`, `Cvv`, `Pin`) VALUES
(1, 2147483647, 'deepa', '2022-04-14', 587, 5258);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(200) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Name`, `Email`, `Phone`, `Password`) VALUES
(5, 'puja', 'an@g.com', '8596742531', 'pooja'),
(6, 'aryan', 'ryansakhala@gmail.com', '8956238965', 'aryansakhla'),
(8, 'puja', 'p@gmail.com', '8754857855', '123456'),
(9, 'aryan', 'r@gmail.com', '3678878789', '123'),
(10, 'aryan', 'aryan@mgail.com', '8748552252', 'aryan123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_cab`
--
ALTER TABLE `book_cab`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cab`
--
ALTER TABLE `cab`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `book_cab`
--
ALTER TABLE `book_cab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `cab`
--
ALTER TABLE `cab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
