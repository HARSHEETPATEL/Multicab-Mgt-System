<?php
//including the database connection file
include_once("db.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($con, "SELECT * FROM book_cab"); // using mysqli_query instead

								
								
							?>
<!DOCTYPE html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="assets/css1/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="assets/css1/style.css" rel='stylesheet' type='text/css' />
<link href="assets/css1/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="assets/css1/font.css" type="text/css"/>
<link href="assets/css1/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="assets/js1/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="index.php" class="logo">
     <h2></h2>
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
    <ul class="nav top-menu">
        <!-- settings start -->
       
        <!-- settings end -->
        <!-- inbox dropdown start-->
        
        <!-- inbox dropdown end -->
        <!-- notification dropdown start-->
       

            </ul>
        </li>
        <!-- notification dropdown end -->
    </ul>
    <!--  notification end -->
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        
        <!-- user login dropdown start-->
        <li class="dropdown">
            
                
              <li><a href="index.php"><i class="fa fa-key"></i> Log Out</a></li>
                
          
            
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->

<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
    <div class="panel panel-default">
    <div class="panel-heading">
    Booking 
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>

	<tr bgcolor='#CCCCCC'>
		<td>NAME</td>
		<td>SOURCE STATION</td>
		<td>FINAL DESTINATION</td>
		<td>NO OF PASSENGERS</td>
		<td>COMPANY NAME</td>
		
	</tr>
        <?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['name']."</td>";
		echo "<td>".$res['source']."</td>";
		echo "<td>".$res['destination']."</td>";	
		echo "<td>".$res['number']."</td>";
		echo "<td>".$res['cmp_name']."</td>";	
			
		//echo "<th><a href=\"edit.php?id=$res[id]\">Edit</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></th>";		
	}
	?>
	
	</table>
    </div>
  </div>
</div>

</section>
 
		  
  <!-- / footer -->
</section>


<!--main content end-->
</section>
<script src="assets/js1/bootstrap.js"></script>
<script src="assets/js1/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/js1/scripts.js"></script>
<script src="assets/js1/jquery.slimscroll.js"></script>
<script src="assets/js1/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="assets/js1/jquery.scrollTo.js"></script>
</body>
</html>

