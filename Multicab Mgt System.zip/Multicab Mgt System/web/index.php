
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> </title>
    <!-- google fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,300&display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--/Header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a class="navbar-brand" href="index.html">
                        <span class="w3yellow">CAB <i class="fa fa-car"></i></span> System
                    </a></h1>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav ms-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link scroll" href="#about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link scroll" href="#cab"> Cabs</a>
                        </li>
						
						
                        
                       
                    </ul>
                    <!--/search-right-->
					<ul class="navbar-nav ms-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                   
                        <li class="nav-item">
						
						<a class="nav-link scroll"href="admin.php">Admin Login</a>
						 </li>
						 <li class="nav-item">
						<div class="dropdown">
						<a class="nav-link scroll" class="dropbtn" href="staff-login.php">Staff Login</a>
						
						 </li>
						 <li class="nav-item">
						
						<a class="nav-link scroll"href="user.php">User Login</a>
						 </li>
                    
					</ul>
                    <!--//search-right-->
                </div>
                <!-- toggle switch for light and dark theme 
                <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>-->
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!--//Header-->
    <!--/Banner-Start-->
    <!--/main-banner-->
    <div class="w3l-main-slider position-relative" id="home">
        <div class="w3l-bannerhny-content">
            <div class="container">
                <div class="w3l-bannerhny-info">
                    
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--//main-banner-->
    <!--/Client-Section-->
    <section id="about" class="clients">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-6 pe-lg-5">
                    <div class="title-content text-left">
                        <h6 class="title-subw3hny mb-2"><span>About Us</span></h6>
                        <h3 class="title-w3l">We take pride in serving our customers safely.</h3>
                    </div>
                </div>
                <div class="col-lg-6 mt-lg-0 mt-md-5 mt-4 ps-lg-5 mx-lg-0">
                    <p class="pr-lg-5">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                        ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet
                        elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit amet.Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                        ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet
                        elit. Non quae, fugiat nihil ad.</p>
                </div>
            </div>

            <div class="car-img mx-0 text-center px-lg-5">
                <img src="assets/images/1.png" alt="" class="img-fluid">
            </div>

        </div>
    </section>
    <!--//client-Section-->
    
    <!--/Counts-Section-->
    
    <!--/Tab-section-->
    
    <!--//abs-Section -->
    <!--/Services-Section -->
    <section id="cab" class="services section-bg w3lpricing">
        <div class="container">
            <div class="section-title">
                
                <h3 class="title-w3l two mb-4">High Quality Services</h3>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-5 mt-4">
                    <div class="box-wrap">
                        <div class="box-wrap-grid">
                            <div class="icon">
                               <img src="assets/images/ola.png" alt="" class="img-fluid">
                            </div>
                            <div class="info">
                                <h4><a href="registration.php">OLA CAB</a></h4>
                                <p class="mt-3" style="text-align:justify;">Ola is India’s largest mobility platform and one of the world’s largest ride-hailing companies, serving 250+ cities across India, Australia, New Zealand, and the UK. </p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-6 col-lg-5 mt-4">
                    <div class="box-wrap">
                        <div class="box-wrap-grid">
                            <div class="icon">
                                 <img src="assets/images/uber.png" alt="" class="img-fluid">
                            </div>
                            <div class="info">
                                <h4><a href="registration.php">
                                        UBER CAB</a></h4>
                                <p class="mt-3" style="text-align:justify;">The idea for Uber was born on a snowy night in Paris in 2008, and ever since then our DNA of reimagination and reinvention carries on.  </p>
                            </div>

                        </div>

                    </div>
                </div>
                
                
                <div class="col-md-6 col-lg-5 mt-4">
                    <div class="box-wrap">
                        <div class="box-wrap-grid">
                            <div class="icon">
                               <img src="assets/images/red.png" alt="" class="img-fluid">
                            </div>
                            <div class="info">
                                <h4><a href="registration.php">

                                        RED BUS</a></h4>
                                <p class="mt-3">redBus is an Indian online bus ticketing platform, providing ticket booking facility through its website, iOS and Android mobile apps. </p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-6 col-lg-5 mt-4">
                    <div class="box-wrap">
                        <div class="box-wrap-grid">
                            <div class="icon">
                                 <img src="assets/images/green.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="info">
                                <h4><a href="registration.php">
                                        GO GREEN</a></h4>
                                <p class="mt-3">Lorem ipsum dolor sit amet consectetur ipsum elit. </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//Services-Section -->
    <!--/-->
    <!--/Team-Section-->
    
    <!--/blog-Section-->
   
    <!--//Team-Section-->
   
    <!--/contact-->
    <section id="contact" class="contact">
        <div class="container">
            
           
        </div>
    </section>
    <!--//contact-->
    <!--/footer-->
    <footer id="footer" class="wthree-footerhny">
        

        <div class="container d-md-flex py-4">

            <div class="me-md-auto text-center text-md-start">
                <div class="copyright">
                    <p class="copy-footer-29">© 2024 Multicab Management System</p>
                </div>

            </div>
            
        </div>
        <button onclick="topFunction()" id="movetop" title="Go to top" style="display: block;">
            <span class="fa fa-angle-up"></span>
        </button>
        <script>
            // When the user scrolls down 20px from the top of the document, show the button
            window.onscroll = function() {
                scrollFunction()
            };

            function scrollFunction() {
                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                    document.getElementById("movetop").style.display = "block";
                } else {
                    document.getElementById("movetop").style.display = "none";
                }
            }

            // When the user clicks on the button, scroll to the top of the document
            function topFunction() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }

        </script>
        <!-- //move top -->
    </footer><!-- End Footer -->


    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/theme-change.js"></script>
   
    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });
        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!-- //MENU-JS -->
    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- //disable body scroll which navbar is in active -->
    <!-- //bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>
