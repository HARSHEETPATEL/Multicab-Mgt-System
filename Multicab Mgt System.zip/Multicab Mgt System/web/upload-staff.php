<html>
<head>
	<title>Add Data</title>
</head>

<body>


<?php
include_once("db.php");
 if(isset($_POST['submit'])) {	
     
    $cmp_name = mysqli_real_escape_string($con, $_POST['cmp_name']);
	$staff_name = mysqli_real_escape_string($con, $_POST['staff_name']);
	$Email = mysqli_real_escape_string($con, $_POST['Email']);
	$Password =  mysqli_real_escape_string($con, $_POST['Password']);
	$phone_no  =  mysqli_real_escape_string($con, $_POST['phone_no']);
	
		
	// checking empty fields
	if( empty($cmp_name) ||empty($staff_name) || empty($Email)|| empty($Password) || empty($phone_no))
	{
				
		
		if(empty($cmp_name)) {
			echo "<font color='red'>cmp_name field is empty.</font><br/>";
		}
		if(empty($staff_name)) {
			echo "<font color='red'>staff_name field is empty.</font><br/>";
		}
		if(empty($Email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($Password)) {
			echo "<font color='red'>Password field is empty.</font><br/>";
		}
		if(empty($phone_no)) {
			echo "<font color='red'>phone_no field is empty.</font><br/>";
		}
		
		
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$row = mysqli_query($con, "INSERT INTO staff(cmp_name,staff_name,Email,Password,phone_no) VALUES('$cmp_name','$staff_name','$Email','$Password','$phone_no')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		//echo "<br/><a href='view-staff.php'>View Result</a>";
	}
}
?>
</body>
</html>
