<!DOCTYPE html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<link rel="stylesheet" href="assets/css1/bootstrap.min.css" >


<link href="assets/css1/style.css" rel='stylesheet' type='text/css' />
<link href="assets/css1/style-responsive.css" rel="stylesheet"/>

<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="assets/css1/font.css" type="text/css"/>
<link href="assets/css1/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="assets/css1/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="assets/css1/monthly.css">

<script src="assets/js1/jquery2.0.3.min.js"></script>
<script src="assets/js1/raphael-min.js"></script>
<script src="assets/js1/morris.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    
    
</div>
<!--logo end-->
<div class="nav notify-row" id="top_menu">
    
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
	   
                <li><a href="view-cab.php">View Cab</a></li>
          <li><a href="index.php"><i class="fa fa-key"></i> Log Out</a></li>
        <!-- user login dropdown start-->
        
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->

    
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
					
                        <div class="panel-body">
                            <div class="position-center">
							
                                <form action="upload-cab.php" method="post" class="form"  enctype="multipart/form-data">
								
								<div class="form-group">
                                    <label for="">SOURCE STATION :</label>
                                    <input type="text" class="form-control" name="source"   placeholder="Name">
                                </div>
								<div class="form-group">
                                    <label for="">FINAL DESTINATION :</label>
                                    <input type="text" class="form-control" name="destination"  placeholder="Range">
                                </div>
								<!--<div class="form-group">
                                     <label for="">NO OF PASSENGERS:</label>
									 <input type="number" class="form-control"  name="number" required  min="1" max="6">
									 
                                      </div>-->
								<div class="form-group">
                                    <label for="">PRICE :</label>
                                    <input type="text" class="form-control" name="price"  placeholder="Range">
                                </div>
								<div class="form-group">
								 <label for="">COMPANY NAME:</label>
								 <select name="cmp_name">
								 <option value="ola"> ola</option>
			                     <option value="uber"> Uber</option>
			                     <option value="red bus"> Red Bus</option>
				                 <option value="go green"> Go Green</option>
								 <option value="rapido">Rapido</option>
				                </select>
								</div>
                                <button type="submit" name="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
                    </section>

				
		</div>
		</div>
		</div>
		
</section>
</section>
								
		</body>
</html>									
								
								
								
                               
                                
                                
              


