<?php
// including the database connection file
include_once("db.php");

if(isset($_POST['submit']))
{	
     $id = mysqli_real_escape_string($con, $_POST['id']);
	$source = mysqli_real_escape_string($con, $_POST['source']);
	$destination = mysqli_real_escape_string($con, $_POST['destination']);
	//$number =  mysqli_real_escape_string($con, $_POST['number']);
	$price =  mysqli_real_escape_string($con, $_POST['price']);
	$cmp_name  =  mysqli_real_escape_string($con, $_POST['cmp_name']);
	
	
	
	// checking empty fields
	if( empty($source) || empty($destination)|| empty($price) || empty($cmp_name))
	{
				
		
		if(empty($source)) {
			echo "<font color='red'>source field is empty.</font><br/>";
		}
		if(empty($destination)) {
			echo "<font color='red'>destination field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>price field is empty.</font><br/>";
		}
		if(empty($cmp_name)) {
			echo "<font color='red'>cmp_name field is empty.</font><br/>";
		}
		
				
	} else {	
		//updating the table
		$result = mysqli_query($con, "UPDATE cab SET source='$source',destination='$destination',price='$price',cmp_name='$cmp_name' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: view-cab.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM cab WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$source = $res['source'];
	$destination = $res['destination'];
	//$number = $res['number'];
	$price = $res['price'];
	$cmp_name = $res['cmp_name'];
	
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
	<a href="view-cab.php">Home</a>
	<br/><br/>
	
	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr> 
				<td>SOURCE STATION:</td>
				<td><input type="text" name="source" value="<?php echo $source;?>"></td>
			</tr>
			<tr> 
				<td>FINAL DESTINATION:</td>
				<td><input type="text" name="destination" value="<?php echo $destination;?>"></td>
			</tr>
			<!--<tr> 
				<td>NO OF PASSENGERS:</td>
				<td><input type="text" name="number" value="<?php echo $number;?>"></td>
			</tr>-->
			<tr> 
				<td>PRICE:</td>
				<td><input type="text" name="price" value="<?php echo $price;?>"></td>
			</tr>
			<tr> 
				<td>COMPANY NAME:</td>
				<td><input type="text" name="cmp_name" value="<?php echo $cmp_name;?>"></td>
			</tr>
			
			<tr>
				<td><input type="hidden" name="id" value="<?php echo $_GET['id'];?>"></td>
				<td><input type="submit" name="submit" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
