<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> </title>
    <!-- google fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,300&display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--/Header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a class="navbar-brand" href="index.html">
                        <span class="w3yellow">CAB <i class="fa fa-car"></i></span> System
                    </a></h1>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    
                    <!--/search-right-->
					<ul class="navbar-nav ms-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                   
                        <li class="nav-item">
						
						<a class="nav-link scroll"href="add-cab.php">Add Cab</a>
						 </li>
						  <li class="nav-item">
						
						<a class="nav-link scroll"href="view-all-cab-booking.php">All Cab Booking</a>
						 </li>
						  <li class="nav-item">
						
						<a class="nav-link scroll"href="add-staff.php">Add Staff</a>
						 </li>
						
						 <li class="nav-item">
						
						<a class="nav-link scroll"href="index.php">Logout</a>
						 </li>
                    
					</ul>
                    <!--//search-right-->
                </div>
                
            </nav>
        </div>
    </header>
    <!--//Header-->
    <!--/Banner-Start-->
    <!--/main-banner-->
    <div class="w3l-main-slider position-relative" id="home">
        <div class="w3l-bannerhny-content">
            <div class="container">
                <div class="w3l-bannerhny-info">
                    
                    
                    </div>
                </div>
            </div>
        </div>
    </div>