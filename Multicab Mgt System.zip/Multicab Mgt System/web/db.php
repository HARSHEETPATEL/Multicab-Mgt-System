<?php
//$con = mysqli_connect("localhost","root","","creativespirits") or die(mysql_error());

$sname = "localhost";
$uname = "root";
$password = "";
$db_name = "multicab";

$con = mysqli_connect($sname, $uname, $password,$db_name);

if(!$con){
	echo "connection failed!";
	exit();
}
if(mysqli_connect_error())
	{
		echo "Connection error".mysqli_connect_error();
		exit;
	}
	if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>


